import numpy as np

# PyCuda imports
import pycuda.autoinit
from pycuda.driver import memcpy_dtod
from pycuda.gpuarray import to_gpu, empty_like, GPUArray
from pycuda.curandom import XORWOWRandomNumberGenerator as RNG
from pycuda.elementwise import ElementwiseKernel

# Needed for FFT
from pyfft.cuda import Plan

# Simulation parameters
lattice_size = 128 # spatial lattice points
domain = (-7, 7) # spatial domain
paths = 8 # simulation paths
U = 1.0
interval = 2.5 # time interval
samples = 100 # how many samples to take during simulation
steps = samples * 400 # number of time steps (should be multiple of samples)
iterations = 3 # number of iterations in semi-implicit integration algorithm
v = 40.0 # strength of the potential
gamma = 0.4
soliton_height = 10.0
soliton_shift = 1.0

# Some additional dependent variables
x = np.linspace(domain[0], domain[1], lattice_size)
dx = x[1] - x[0]
k = np.fft.fftfreq(lattice_size, dx) * 2.0 * np.pi
prop_k = (-0.5j * (k ** 2)).astype(np.complex64)
dt = float(interval) / steps

# Kernel for propagation in momentum space
kPropagate = ElementwiseKernel(
	"pycuda::complex<float> *psi_kspace, pycuda::complex<float> *ks",
	"psi_kspace[i] = psi_kspace[i] * ks[i]")

# Kernel for propagation in coordinate space
xPropagate = ElementwiseKernel(
	"""
	pycuda::complex<float> *psi,
	pycuda::complex<float> *psi_copy,
	pycuda::complex<float> *psi_kspace,
	float *V,
	float dt,
	float *noise
	""",
	"""
	psi[i] = psi_copy[i] + (
			psi_kspace[i]
			- pycuda::complex<float>(0, 1) * ((float){U} * norm(psi[i]) + V[i]) * psi[i]
			- (float){gamma} * psi[i]
			+ (float){noise_coeff} * pycuda::complex<float>(noise[i], noise[i + n])
		) * dt
	""".format(U=U, gamma=gamma, noise_coeff=np.sqrt(gamma * 0.5 / dx / dt)))

# Allocate arrays
psi0 = soliton_height / np.cosh(x - soliton_shift)
random_normals = (
	np.random.normal(size=(paths,lattice_size)) +
	1j * np.random.normal(size=(paths,lattice_size))) / np.sqrt(2)
initial_noise = random_normals / np.sqrt(2 * dx)
psi0 = (np.tile(psi0, (paths, 1)) + initial_noise).astype(np.complex64)

V = np.tile(v * x ** 2, (paths, 1)).astype(np.float32)

V_gpu = to_gpu(V)
psi_gpu = GPUArray(psi0.shape, psi0.dtype)
prop_k_gpu = to_gpu(np.tile(prop_k, (paths, 1)))
psi_kspace_gpu = empty_like(psi_gpu)
psi_copy_gpu = empty_like(psi_gpu)
noise_gpu = GPUArray((2, paths, lattice_size), np.float32)

rng = RNG()

# FFT plan
plan = Plan((lattice_size,), dtype=np.complex64)

def integrate():

	# Sampled results will be stored here
	results = np.empty((samples + 1, paths, lattice_size), dtype=np.complex64)

	# initialize \psi
	psi_gpu.set(psi0)

	step = 0
	sample = 0

	for step in xrange(steps):

		rng.fill_normal(noise_gpu)

		# Make a copy of current \psi value
		memcpy_dtod(psi_copy_gpu.gpudata, psi_gpu.gpudata, psi_gpu.nbytes)

		for i in xrange(iterations):
			temp_dt = np.float32(dt if i == iterations - 1 else dt / 2)

			plan.execute(psi_gpu, psi_kspace_gpu, batch=paths)
			kPropagate(psi_kspace_gpu, prop_k_gpu)
			plan.execute(psi_kspace_gpu, inverse=True, batch=paths)
			xPropagate(psi_gpu, psi_copy_gpu, psi_kspace_gpu,
				V_gpu, temp_dt, noise_gpu)

		# Sampling
		if step == 0 or (step + 1) % (steps / samples) == 0:
			results[sample] = psi_gpu.get()
			sample += 1

	return results

if __name__ == '__main__':

	# Run integration
	psis = integrate()

	# Average |\psi|^2 over integration paths
	density = (np.abs(psis) ** 2).mean(1) - 0.5 / dx

	# Plot |\psi|^2
	import matplotlib
	matplotlib.use('Agg')
	import matplotlib.pyplot
	import mpl_toolkits.mplot3d

	fig = matplotlib.pyplot.figure()
	s = fig.add_subplot(111)
	s.imshow(density.T, interpolation='nearest', origin='lower', aspect='auto',
		extent=(0, interval) + domain, vmin=0)
	s.set_xlabel('$t$')
	s.set_ylabel('$x$')

	fig.savefig('bec3.pdf')
