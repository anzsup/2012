import numpy as np

# PyCuda imports
import pycuda.autoinit
from pycuda.driver import memcpy_dtod
from pycuda.gpuarray import to_gpu, empty_like, GPUArray
from pycuda.elementwise import ElementwiseKernel

# Needed for FFT
from pyfft.cuda import Plan

# Simulation parameters
lattice_size = 128 # spatial lattice points
domain = (-7, 7) # spatial domain
U = 1.0
interval = 2.5 # time interval
samples = 100 # how many samples to take during simulation
steps = samples * 100 # number of time steps (should be multiple of samples)
iterations = 3 # number of iterations in semi-implicit integration algorithm
v = 40.0 # strength of the potential
soliton_height = 10.0
soliton_shift = 1.0

# Some additional dependent variables
x = np.linspace(domain[0], domain[1], lattice_size)
dx = x[1] - x[0]
k = np.fft.fftfreq(lattice_size, dx) * 2.0 * np.pi
prop_k = (-0.5j * (k ** 2)).astype(np.complex64)

# Kernel for propagation in momentum space
kPropagate = ElementwiseKernel(
	"pycuda::complex<float> *psi_kspace, pycuda::complex<float> *ks",
	"psi_kspace[i] = psi_kspace[i] * ks[i]")

# Kernel for propagation in coordinate space
xPropagate = ElementwiseKernel(
	"""
	pycuda::complex<float> *psi,
	pycuda::complex<float> *psi_copy,
	pycuda::complex<float> *psi_kspace,
	float *V,
	float dt
	""",
	"""
	psi[i] = psi_copy[i] + (
			psi_kspace[i]
			- pycuda::complex<float>(0, 1) * ((float){U} * norm(psi[i]) + V[i]) * psi[i]
		) * dt
	""".format(U=U))

# Allocate arrays
psi0 = (soliton_height / np.cosh(x - soliton_shift)).astype(np.complex64)
V = (v * x ** 2 / 2).astype(np.float32)

V_gpu = to_gpu(V)
psi_gpu = GPUArray(psi0.shape, psi0.dtype)
prop_k_gpu = to_gpu(prop_k)
psi_kspace_gpu = empty_like(psi_gpu)
psi_copy_gpu = empty_like(psi_gpu)

# FFT plan
plan = Plan((lattice_size,), dtype=np.complex64)

def integrate():

	# Sampled results will be stored here
	results = np.empty((samples + 1, lattice_size), np.complex64)

	# initialize \psi
	psi_gpu.set(psi0)

	dt = float(interval) / steps

	step = 0
	sample = 0

	for step in xrange(steps):

		# Make a copy of current \psi value
		memcpy_dtod(psi_copy_gpu.gpudata, psi_gpu.gpudata, psi_gpu.nbytes)

		for i in xrange(iterations):
			temp_dt = np.float32(dt if i == iterations - 1 else dt / 2)

			plan.execute(psi_gpu, psi_kspace_gpu)
			kPropagate(psi_kspace_gpu, prop_k_gpu)
			plan.execute(psi_kspace_gpu, inverse=True)
			xPropagate(psi_gpu, psi_copy_gpu, psi_kspace_gpu, V_gpu, temp_dt)

		# Sampling
		if step == 0 or (step + 1) % (steps / samples) == 0:
			results[sample] = psi_gpu.get()
			sample += 1

	return results

if __name__ == '__main__':

	# Run integration
	psis = integrate()
	density = np.abs(psis) ** 2

	# Plot |\psi|^2
	import matplotlib
	matplotlib.use('Agg')
	import matplotlib.pyplot
	import mpl_toolkits.mplot3d

	t = np.linspace(0, interval, samples + 1)

	fig = matplotlib.pyplot.figure()
	s = fig.add_subplot(111)
	s.imshow(density.T, interpolation='nearest', origin='lower', aspect='auto',
		extent=(0, interval) + domain)
	s.set_xlabel('$t$')
	s.set_ylabel('$x$')

	fig.savefig('bec1.pdf')
