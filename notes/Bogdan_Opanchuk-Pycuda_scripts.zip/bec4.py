import time
import numpy as np

# PyCuda imports
import pycuda.autoinit
from pycuda.driver import Stream, memcpy_dtod_async
from pycuda.gpuarray import *
from pycuda.compiler import SourceModule
from pycuda.curandom import XORWOWRandomNumberGenerator as RNG
from pycuda.elementwise import ElementwiseKernel
from pycuda.compyte.dtypes import dtype_to_ctype

# Needed for FFT
from pyfft.cuda import Plan

# Simulation parameters
seed = 31415926 # random seed
lattice_size = 128 # spatial lattice points
domain = (-7, 7) # spatial domain
paths = 8 # simulation paths
U = 1.0
interval = 2.5 # time interval
samples = 100 # how many samples to take during simulation
steps = samples * 400 # number of time steps (should be multiple of samples)
iterations = 3 # number of iterations in semi-implicit integration algorithm
v = 40.0 # strength of the potential
gamma = 0.4
soliton_height = 10.0
soliton_shift = 1.0
float_dtype = np.float32
complex_dtype = np.complex64

# Some additional dependent variables
complex_name = dtype_to_ctype(complex_dtype)
float_name = dtype_to_ctype(float_dtype)

x = np.linspace(domain[0], domain[1], lattice_size)
dx = x[1] - x[0]
k = np.fft.fftfreq(lattice_size, dx) * 2.0 * np.pi
prop_k = (-0.5j * (k ** 2)).astype(complex_dtype)
noise_dt = float(interval) / steps / 2

# Kernel for propagation in momentum space
kPropagate = ElementwiseKernel(
	"{cname} *psi_kspace, {cname} *ks".format(cname=complex_name),
	"psi_kspace[i] = psi_kspace[i] * ks[i]")

# Kernel for propagation in coordinate space
xPropagate = ElementwiseKernel(
	"""
	{cname} *psi,
	{cname} *psi_copy,
	{cname} *psi_kspace,
	{fname} *V,
	{fname} dt,
	{fname} *noise1,
	{fname} *noise2,
	int half_step""".format(cname=complex_name, fname=float_name),
	"""
	{fname} eta1 = half_step ? noise1[i] : (noise1[i] + noise2[i]) / 2;
	{fname} eta2 = half_step ? noise1[i + n] : (noise1[i + n] + noise2[i + n]) / 2;
	psi[i] = psi_copy[i] + (
			psi_kspace[i]
			- {cname}(0, 1) * (({fname}){U} * norm(psi[i]) + V[i]) * psi[i]
			- ({fname}){gamma} * psi[i]
			+ ({fname}){noise_coeff} * {cname}(eta1, eta2)
		) * dt
	""".format(fname=float_name, cname=complex_name,
		U=U, gamma=gamma, noise_coeff=np.sqrt(gamma * 0.5 / dx / noise_dt)))

# Allocate arrays
psi0 = soliton_height / np.cosh(x - soliton_shift)
random_normals = (
	np.random.normal(size=(paths,lattice_size)) +
	1j * np.random.normal(size=(paths,lattice_size))) / np.sqrt(2)
initial_noise = random_normals / np.sqrt(2 * dx)
psi0 = (np.tile(psi0, (paths, 1)) + initial_noise).astype(complex_dtype)
V = np.tile(v * x ** 2, (paths, 1)).astype(float_dtype)

V_gpu = to_gpu(V)
psi_gpu = GPUArray(psi0.shape, psi0.dtype)
prop_k_gpu = to_gpu(np.tile(prop_k, (paths, 1)))
psi_kspace_gpu = empty_like(psi_gpu)
psi_copy_gpu = empty_like(psi_gpu)
noise1_gpu = GPUArray((2, paths, lattice_size), dtype=float_dtype)
noise2_gpu = GPUArray((2, paths, lattice_size), dtype=float_dtype)


def integrate(half_step):

	stream = Stream()

	# FFT plan
	plan = Plan((lattice_size,), dtype=complex_dtype, stream=stream)

	# make sure both full-step and half-step integration use the same random sequence
	np.random.seed(seed)
	rng = RNG()

	# Sampled results will be stored here
	results = np.empty((samples + 1, paths, lattice_size), dtype=complex_dtype)

	# initialize \psi
	psi_gpu.set(psi0)

	dt = float(interval) / steps / (2 if half_step else 1)

	step = 0
	sample = 0

	for step in xrange(steps * (2 if half_step else 1)):

		# In order to estimate the error, we need to draw random numbers
		# so that at the beginning of each full step the RNG state is the same
		if half_step:
			rng.fill_normal(noise1_gpu, stream=stream)
		else:
			rng.fill_normal(noise1_gpu, stream=stream)
			rng.fill_normal(noise2_gpu, stream=stream)

		# Make a copy of current \psi value
		memcpy_dtod_async(psi_copy_gpu.gpudata, psi_gpu.gpudata, psi_gpu.nbytes, stream=stream)

		for i in xrange(iterations):
			temp_dt = float_dtype(dt if i == iterations - 1 else dt / 2)

			plan.execute(psi_gpu, psi_kspace_gpu, batch=paths)
			kPropagate(psi_kspace_gpu, prop_k_gpu, stream=stream)
			plan.execute(psi_kspace_gpu, inverse=True, batch=paths)

			xPropagate(psi_gpu, psi_copy_gpu, psi_kspace_gpu,
				V_gpu, temp_dt, noise1_gpu, noise2_gpu, np.int32(half_step), stream=stream)

		# Sampling
		if step == 0 or (step + 1) % (steps / samples * (2 if half_step else 1)) == 0:
			stream.synchronize()
			results[sample] = psi_gpu.get()
			sample += 1

	return results

if __name__ == '__main__':

	# Run integration
	t = time.time()
	psis = integrate(False)
	psis_half = integrate(True)
	print "time =", time.time() - t, "s"

	print "error:", np.linalg.norm(psis[-1] - psis_half[-1]) / np.linalg.norm(psis_half[-1])

	# Average |\psi|^2 over integration paths
	density = (np.abs(psis) ** 2).mean(1) - 0.5 / dx
	density_half = (np.abs(psis_half) ** 2).mean(1) - 0.5 / dx

	# Plot |\psi|^2
	import matplotlib
	matplotlib.use('Agg')
	import matplotlib.pyplot
	import mpl_toolkits.mplot3d

	fig = matplotlib.pyplot.figure()
	s = fig.add_subplot(111)
	s.imshow(density.T, interpolation='nearest', origin='lower', aspect='auto',
		extent=(0, interval) + domain, vmin=0)
	s.set_xlabel('$t$')
	s.set_ylabel('$x$')

	fig.savefig('bec4.pdf')
