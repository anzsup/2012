import pycuda.autoinit
from pycuda.gpuarray import to_gpu, empty_like
from pycuda.elementwise import ElementwiseKernel

import numpy as np

a = np.random.randn(400).astype(np.float32)
b = np.random.randn(400).astype(np.float32)

mul = ElementwiseKernel(
	"float *dest, float *a, float *b",
	"dest[i] = a[i] * b[i]")

a_gpu = to_gpu(a)
b_gpu = to_gpu(b)
dest_gpu = empty_like(a_gpu)

mul(dest_gpu, a_gpu, b_gpu)

print (a * b - dest_gpu.get())
